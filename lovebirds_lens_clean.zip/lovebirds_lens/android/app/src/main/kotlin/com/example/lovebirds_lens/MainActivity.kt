package com.example.lovebirds_lens

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
